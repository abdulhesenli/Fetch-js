// let tbl = document.querySelector("#tbl");
// let link;


// function Tbl() {

//     link = fetch("https://jsonplaceholder.typicode.com/todos").then(response => {
//         // console.log(response);
//         response.json().then(value => {
//             console.log(value);
//             // tbl.innerHTML=value;
//             value.forEach(element => {
//                 cvb = `<thead>
//                 <th scope="col">${element.id} </th>
//                 <th scope="col">${element.userId} </th>
//                 <th scope="col">${element.title} </th>
//                 <th scope="col">${element.completed} </th>
            
//             </thead>`
//                 // for (let i = o; i <element. length; i++) {
//                 //     cvb += `<tr>`

//                 //     cvb += `<td> ${element.id} </td> `
//                 //     cvb += `<td> ${element.userId} </td> `
//                 //     cvb += `<td> ${element.title} </td> `
//                 //     cvb += `<td> ${element.completed} </td> `

//                 //     cvb += `</tr>`

//                 //     // tbl.innerHTML += `${element.id} - ${element.title}`

//                 // }
//                 tbl.innerHTML += cvb;
//             });
//         });



//     });
// }
// Tbl()


let sh=document.querySelector("#show");

fetch("http://api.weatherapi.com/v1/forecast.json?key=65e2615530db476aa53173106220901&q=Baku&days=7&aqi=no&alerts=no").then(response=>{

// sh.innerHTML=response.url
    response.json().then(value=>{
        value.forEach(element => {
            sh.innerHTML=element.url
            
        });
    })
})
